public class Player extends Entity {
}
