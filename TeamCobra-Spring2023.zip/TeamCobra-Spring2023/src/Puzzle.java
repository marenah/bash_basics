public class Puzzle {
}
