public class Monster extends Entity {
}
