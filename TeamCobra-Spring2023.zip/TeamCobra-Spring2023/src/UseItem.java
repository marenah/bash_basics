public class UseItem extends Item{
}
