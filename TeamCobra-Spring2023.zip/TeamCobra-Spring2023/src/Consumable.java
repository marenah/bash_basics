public class Consumable extends Item{
}
