public class Equipment extends Item{
}
